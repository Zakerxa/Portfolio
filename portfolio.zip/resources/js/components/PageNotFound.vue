<template>
  <div class="container">
    <div class="row d-flex justify-content-center align-items-center w-100" style="min-height:100vh">
        <div class="col-10 col-sm-8 col-md-6 col-lg-4 text-center pt-5">
            <img src="/images/icon/error.png" draggable="false" style="width:50%" alt="">
            <h2 class="text-danger fw-bold pt-4">Page Not Found</h2>
        </div>
    </div>
  </div>
</template>
